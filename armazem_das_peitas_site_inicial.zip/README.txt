# Armazém das Peitas

Primeira versão do catálogo online.

## Arquivos
- index.html — página principal
- style.css — visual
- script.js — filtros do catálogo

## WhatsApp
Número configurado: (19) 99938-3566

## Próximos passos
1. Trocar os produtos fictícios pelas camisas reais.
2. Adicionar fotos reais.
3. Definir preços e tamanhos.
4. Adicionar logo final.
5. Publicar gratuitamente no GitHub Pages ou outra hospedagem estática.
