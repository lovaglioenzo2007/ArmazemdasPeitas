const filters = document.querySelectorAll('.filter');
const products = document.querySelectorAll('.product');

filters.forEach(btn => {
  btn.addEventListener('click', () => {
    filters.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const category = btn.dataset.filter;
    products.forEach(product => {
      product.style.display = (category === 'todos' || product.dataset.category === category) ? '' : 'none';
    });
  });
});

document.querySelectorAll('[data-jump]').forEach(btn => {
  btn.addEventListener('click', () => {
    const category = btn.dataset.jump;
    document.querySelector(`.filter[data-filter="${category}"]`).click();
    document.querySelector('#catalogo').scrollIntoView({behavior:'smooth'});
  });
});
